package com.nexus.sidekick;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.graphics.Color;import android.view.*;import android.widget.*;
public class MainActivity extends Activity {
 LinearLayout root;
 @Override public void onCreate(Bundle b){super.onCreate(b);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(40,70,40,20);root.setBackgroundColor(Color.rgb(12,15,26));setContentView(root);
 TextView title=new TextView(this);title.setText("NEXUS // SIDEKICK\nCORE v0.1");title.setTextColor(0xff75e5ff);title.setTextSize(25);root.addView(title);
 TextView status=new TextView(this);status.setText("Local commands only. No API, microphone or accessibility access.");status.setTextColor(Color.WHITE);status.setPadding(0,25,0,25);root.addView(status);
 Button grant=new Button(this);grant.setText("1. Allow floating window");root.addView(grant);grant.setOnClickListener(v->{if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));else Toast.makeText(this,"Overlay permission already granted",Toast.LENGTH_SHORT).show();});
 Button start=new Button(this);start.setText("2. Show Sidekick");root.addView(start);start.setOnClickListener(v->{if(Settings.canDrawOverlays(this))startService(new Intent(this,OverlayService.class));else Toast.makeText(this,"Grant overlay permission first",Toast.LENGTH_LONG).show();});
 Button stop=new Button(this);stop.setText("Stop Sidekick");root.addView(stop);stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class)));
 Button test=new Button(this);test.setText("Test YouTube search");root.addView(test);test.setOnClickListener(v->Actions.searchYouTube(this,"Android tutorials"));
 }
}
