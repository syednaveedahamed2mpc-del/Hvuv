package com.nexus.sidekick;
import android.content.*;import android.net.Uri;import android.widget.Toast;
public final class Actions { private Actions(){} public static void searchYouTube(Context c,String query){
 Uri u=Uri.parse("https://www.youtube.com/results").buildUpon().appendQueryParameter("search_query",query).build();Intent i=new Intent(Intent.ACTION_VIEW,u);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
 try {c.startActivity(i);}catch(Exception e){Toast.makeText(c,"No app can open YouTube search",Toast.LENGTH_LONG).show();}
 } }
