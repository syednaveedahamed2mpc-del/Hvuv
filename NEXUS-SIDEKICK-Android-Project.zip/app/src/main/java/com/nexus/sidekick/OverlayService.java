package com.nexus.sidekick;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.PixelFormat;import android.view.*;import android.widget.*;
public class OverlayService extends Service {
 WindowManager wm;View panel;boolean expanded=false;
 @Override public int onStartCommand(Intent i,int flags,int id){if(panel==null)show();return START_NOT_STICKY;}
 void show(){if(!android.provider.Settings.canDrawOverlays(this)){stopSelf();return;}wm=(WindowManager)getSystemService(WINDOW_SERVICE);
 LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(12,12,12,12);l.setBackgroundColor(0xee111b30);
 Button toggle=new Button(this);toggle.setText("✦");l.addView(toggle);
 Button youtube=new Button(this);youtube.setText("YouTube: Android tutorials");youtube.setVisibility(View.GONE);l.addView(youtube);
 Button close=new Button(this);close.setText("Close");close.setVisibility(View.GONE);l.addView(close);
 toggle.setOnClickListener(v->{expanded=!expanded;youtube.setVisibility(expanded?View.VISIBLE:View.GONE);close.setVisibility(expanded?View.VISIBLE:View.GONE);});
 youtube.setOnClickListener(v->Actions.searchYouTube(this,"Android tutorials"));close.setOnClickListener(v->stopSelf());
 WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;
 panel=l;try{wm.addView(panel,lp);}catch(Exception e){stopSelf();}
 }
 @Override public void onDestroy(){if(wm!=null&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
