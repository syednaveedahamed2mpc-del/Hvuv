# NEXUS Sidekick core v0.1
Minimal native Android prototype for Motorola Edge 70 Fusion / Android 17 testing.

## Implemented
- Permission request for Android overlay
- Collapsible edge bubble overlay (user started, no background persistence)
- One deterministic YouTube search action via HTTPS VIEW intent
- Stop service and remove overlay

## Deliberately NOT implemented
- AI provider, microphone, wake word, Accessibility Service, arbitrary phone control, voice output, background autostart.

## Build
Import this directory into Android Studio with Android SDK 35, or push files to GitHub and run the included Build Android APK workflow. Download the debug APK artifact. No Gradle wrapper is included; GitHub workflow provisions Gradle 8.11.1.

## Test on device
Install APK, open, grant Display over other apps, reopen, Show Sidekick, tap edge bubble, test YouTube, close. Motorola's own Sidebar may occupy the same edge; move/disable the Motorola sidebar if they conflict.

## Caveats
This code has not been compiled or tested on the physical phone in this environment. Android may hide overlay on secure screens. User must explicitly grant overlay permission. Overlay runs as a started service, not a long-running foreground service; Android can stop it under memory/battery pressure. This is intentionally a feasibility prototype, not a guaranteed always-on agent.
